#pragma once


#include "../src/protobufs/generated/AuthData.pb.h"
#include "../src/protobufs/generated/ClientConfigData.pb.h"
#include "../src/protobufs/generated/ClientLog.pb.h"
#include "../src/protobufs/generated/ClientMetrics.pb.h"
#include "../src/protobufs/generated/ClientTelemetry.pb.h"
#include "../src/protobufs/generated/Common.pb.h"
#include "../src/protobufs/generated/CustomerServiceData.pb.h"
#include "../src/protobufs/generated/Error.pb.h"
#include "../src/protobufs/generated/GambleData.pb.h"
#include "../src/protobufs/generated/GameplayConfigData.pb.h"
#include "../src/protobufs/generated/GetFriendData.pb.h"
#include "../src/protobufs/generated/LandData.pb.h"
#include "../src/protobufs/generated/MatchmakingData.pb.h"
#include "../src/protobufs/generated/OffersData.pb.h"
#include "../src/protobufs/generated/PurchaseData.pb.h"
#include "../src/protobufs/generated/WholeLandTokenData.pb.h"
